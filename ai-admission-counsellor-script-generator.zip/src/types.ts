export interface GeneratedScript {
  greeting: string;
  rapportBuilding: string;
  needAnalysis: string[];
  programIntroduction: string;
  objectionHandling: string;
  closing: string;
  whatsappMessage: string;
}

export interface SavedScript {
  id: string;
  title: string;
  parentQuery: string;
  childAge: number;
  programInterest: string;
  script: GeneratedScript;
  createdAt: string;
  type: "ai" | "template";
}
