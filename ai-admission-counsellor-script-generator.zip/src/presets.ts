export interface Preset {
  id: string;
  label: string;
  parentQuery: string;
  childAge: number;
  programInterest: string;
  tag: string;
}

export const PRESETS: Preset[] = [
  {
    id: "fees",
    label: "Price Objection",
    parentQuery: "The fees are way too high compared to other local classes.",
    childAge: 8,
    programInterest: "Coding & Game Development",
    tag: "Finance",
  },
  {
    id: "screentime",
    label: "Screen Time Concern",
    parentQuery: "My child is already on safe iPads/screens all day. I don't want more screen time.",
    childAge: 6,
    programInterest: "Robotics & Hardware Lab",
    tag: "Well-being",
  },
  {
    id: "analytics",
    label: "Academic Relevance",
    parentQuery: "How does this hobby class help them improve their school grades and exam performance?",
    childAge: 12,
    programInterest: "Adversarial Chess & Logic Math",
    tag: "Academics",
  },
  {
    id: "young",
    label: "Too Young / Complex",
    parentQuery: "He is only five. I think coding and logic will be far too complicated and boring for him.",
    childAge: 5,
    programInterest: "Scratch Jr. Visual Logic",
    tag: "Pedagogy",
  },
  {
    id: "career",
    label: "Career / Future Value",
    parentQuery: "Is this program certified? Will this actually build a portfolio that helps for college applications?",
    childAge: 15,
    programInterest: "Python Web & AI Development",
    tag: "Future Career",
  }
];
