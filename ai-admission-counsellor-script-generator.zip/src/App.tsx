/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Sparkles, 
  Zap, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Bookmark, 
  Trash2, 
  ArrowRight, 
  Phone, 
  MessageSquare, 
  FileText, 
  User, 
  Clock, 
  HeartHandshake, 
  HelpCircle, 
  RotateCcw,
  BookOpen
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PRESETS, Preset } from "./presets";
import { GeneratedScript, SavedScript } from "./types";
import { generateLocalFallback } from "./utils/templateGenerator";

export default function App() {
  // Input states
  const [parentQuery, setParentQuery] = useState("");
  const [childAge, setChildAge] = useState<number | "">("");
  const [programInterest, setProgramInterest] = useState("");
  
  // Selected option states
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"phone" | "whatsapp">("phone");
  const [activeSection, setActiveSection] = useState<string>("greeting");
  
  // App system states
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generationType, setGenerationType] = useState<"ai" | "template" | null>(null);
  const [script, setScript] = useState<GeneratedScript | null>(null);
  const [savedScripts, setSavedScripts] = useState<SavedScript[]>([]);
  
  // UX UI helpers
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [syntheticVoice, setSyntheticVoice] = useState<SpeechSynthesisVoice | null>(null);

  // Load saved scripts & initialize speech synthesis on mount
  useEffect(() => {
    const local = localStorage.getItem("counsellor_saved_scripts");
    if (local) {
      try {
        setSavedScripts(JSON.parse(local));
      } catch (e) {
        console.error("Failed to load saved templates", e);
      }
    }
    
    // Choose voice for browser TTS if available (prefers soft/professional-sounding)
    if (typeof window !== "undefined" && window.speechSynthesis) {
      const handleVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        // Prefers clean English voice
        const preferred = voices.find(v => v.lang.startsWith("en") && (v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Samantha")));
        setSyntheticVoice(preferred || voices[0] || null);
      };
      
      handleVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = handleVoices;
      }
    }
  }, []);

  // Save scripts to local storage helper
  const saveScriptsToStorage = (updatedList: SavedScript[]) => {
    setSavedScripts(updatedList);
    localStorage.setItem("counsellor_saved_scripts", JSON.stringify(updatedList));
  };

  // Preset Applier
  const applyPreset = (preset: Preset) => {
    setParentQuery(preset.parentQuery);
    setChildAge(preset.childAge);
    setProgramInterest(preset.programInterest);
    setActivePreset(preset.id);
  };

  // Clear Form Inputs
  const handleReset = () => {
    setParentQuery("");
    setChildAge("");
    setProgramInterest("");
    setActivePreset(null);
    setScript(null);
    setGenerationType(null);
    setError(null);
    if (isSpeaking) {
      stopSpeech();
    }
  };

  // Generate with AI calling Express Backend Route /api/generate
  const generateWithAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentQuery || !childAge || !programInterest) {
      setError("Please fill in all inputs before generating.");
      return;
    }

    setLoading(true);
    setError(null);
    if (isSpeaking) {
      stopSpeech();
    }

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          parentQuery,
          childAge,
          programInterest
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({ error: "Server response was not OK" }));
        throw new Error(errJson.error || "Failed to contact generator backend");
      }

      const data = await res.json();
      setScript(data);
      setGenerationType("ai");
    } catch (err: any) {
      console.error(err);
      setError(
        err.message || 
        "The server is initializing or the API Key might be missing in Secrets. Please try checking your app parameters."
      );
      // Automatically fallback to local template if AI fails
      const fallback = generateLocalFallback(parentQuery, Number(childAge), programInterest);
      setScript(fallback);
      setGenerationType("template");
    } finally {
      setLoading(false);
    }
  };

  // Generate with local dynamic template instantly
  const generateWithTemplate = () => {
    if (!parentQuery || !childAge || !programInterest) {
      setError("Please fill in all inputs before running the template.");
      return;
    }
    setError(null);
    setLoading(true);
    if (isSpeaking) {
      stopSpeech();
    }

    setTimeout(() => {
      try {
        const localScript = generateLocalFallback(parentQuery, Number(childAge), programInterest);
        setScript(localScript);
        setGenerationType("template");
      } catch (err: any) {
        setError("Error rendering localized script.");
      } finally {
        setLoading(false);
      }
    }, 300);
  };

  // Save current script to notebook
  const handleSaveScript = () => {
    if (!script) return;
    const title = `${programInterest} - ${childAge} yrs old (${activePreset ? PRESETS.find(p => p.id === activePreset)?.label : "Custom"})`;
    const newScript: SavedScript = {
      id: "script_id_" + Date.now(),
      title,
      parentQuery,
      childAge: Number(childAge),
      programInterest,
      script,
      createdAt: new Date().toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }),
      type: generationType || "template"
    };

    const updated = [newScript, ...savedScripts];
    saveScriptsToStorage(updated);
  };

  // Remove saved script
  const handleDeleteSaved = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = savedScripts.filter((s) => s.id !== id);
    saveScriptsToStorage(filtered);
  };

  // Load a saved script from notebook
  const handleLoadSaved = (saved: SavedScript) => {
    setParentQuery(saved.parentQuery);
    setChildAge(saved.childAge);
    setProgramInterest(saved.programInterest);
    setScript(saved.script);
    setGenerationType(saved.type);
    setError(null);
    // Find preset if matches query
    const foundPreset = PRESETS.find(p => p.parentQuery === saved.parentQuery);
    setActivePreset(foundPreset ? foundPreset.id : null);
  };

  // Copy specific element text to clipboard
  const copyToClipboard = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(identifier);
    setTimeout(() => {
      setCopiedSection(null);
    }, 2000);
  };

  // Copy full generated script to clipboard
  const copyAllScript = () => {
    if (!script) return;
    const fullText = `
=== CALLING SCRIPT: ${programInterest} (Age: ${childAge}) ===

GREETING:
${script.greeting}

RAPPORT BUILDING:
${script.rapportBuilding}

NEED ANALYSIS QUESTIONS:
${script.needAnalysis.map((q, idx) => `${idx + 1}. ${q}`).join("\n")}

PROGRAM INTRODUCTION:
${script.programIntroduction}

OBJECTION HANDLING:
${script.objectionHandling}

CALL CLOSING:
${script.closing}

=== WHATSAPP FOLLOW-UP MESSAGE ===
${script.whatsappMessage}
    `.trim();

    navigator.clipboard.writeText(fullText);
    setCopiedAll(true);
    setTimeout(() => {
      setCopiedAll(false);
    }, 2000);
  };

  // Web Speech Client-Side Reading Practice
  const handleSpeak = (text: string, identifier: string) => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;

    if (isSpeaking === identifier) {
      stopSpeech();
      return;
    }

    window.speechSynthesis.cancel(); // cancel current speech
    
    // Clean text by stripping out emoji characters or markdown formatting before reading for better pronunciation
    const cleanText = text
      .replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD00-\uDFFF]/g, "")
      .replace(/\*/g, "")
      .replace(/•/g, "dot");

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (syntheticVoice) {
      utterance.voice = syntheticVoice;
    }
    // Set natural rate
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      setIsSpeaking(null);
    };

    utterance.onerror = () => {
      setIsSpeaking(null);
    };

    setIsSpeaking(identifier);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeech = () => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(null);
  };

  // Editable script section handler
  const handleSectionTextChange = (field: keyof GeneratedScript, newValue: string) => {
    if (!script) return;
    setScript({
      ...script,
      [field]: newValue
    });
  };

  const handleNeedAnalysisChange = (index: number, newValue: string) => {
    if (!script) return;
    const updatedNeeds = [...script.needAnalysis];
    updatedNeeds[index] = newValue;
    setScript({
      ...script,
      needAnalysis: updatedNeeds
    });
  };

  return (
    <div className="min-h-screen bg-natural-bg text-natural-text-main selection:bg-natural-border selection:text-natural-olive pb-16 font-sans antialiased">
      {/* Upper Brand Header */}
      <header className="border-b border-natural-border bg-natural-card sticky top-0 z-10 shadow-[0_2px_12px_rgba(0,0,0,0.02)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-natural-olive text-white rounded-2xl shadow-sm">
              <Sparkles className="w-5 h-5 pointer-events-none" id="header-brand-icon" />
            </div>
            <div>
              <h1 className="font-serif text-2xl font-bold tracking-tight text-natural-olive">
                Lumina Academy
              </h1>
              <p className="text-[10px] text-natural-text-muted uppercase tracking-wider block font-semibold -mt-0.5 tracking-widest font-sans">
                Admission Intelligence v2.0
              </p>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <div className="hidden md:flex items-center gap-6 font-sans text-xs font-semibold text-natural-text-muted">
              <span className="cursor-pointer hover:text-natural-text-main">Dashboard</span>
              <span className="text-natural-olive underline underline-offset-8 decoration-2 font-bold select-none">Script Generator</span>
              <span className="cursor-pointer hover:text-natural-text-main">Analytics</span>
            </div>
            
            <span className="hidden sm:inline bg-[#fafaf8] border border-natural-border text-natural-olive text-[10px] font-mono px-2 py-1 rounded-md font-semibold shrink-0">
              SERVER-SIDE GEMINI READY
            </span>
            
            <button 
              onClick={handleReset} 
              className="text-natural-text-muted hover:text-natural-text-main transition-all p-2 rounded-lg hover:bg-natural-bg/40 text-xs flex items-center gap-1.5 cursor-pointer font-semibold"
              title="Reset all inputs"
              id="btn-reset-form"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT PANEL: Input Form and Controls */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* 1. Quick Launch Preset Scenarios */}
            <div className="bg-natural-card border border-natural-border rounded-[24px] p-6 shadow-[0_4px_20px_rgba(0,0,0,0.02)]">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-[#fafaf8] text-natural-olive rounded-md border border-natural-border/60">
                    <Zap className="w-4 h-4" />
                  </div>
                  <h2 className="text-xs font-bold text-natural-olive uppercase tracking-wider">
                    Quick Objection Presets
                  </h2>
                </div>
                <span className="text-[10px] text-natural-text-muted font-medium italic">Click to apply</span>
              </div>

              <div className="flex flex-wrap gap-2.5">
                {PRESETS.map((p) => {
                  const isActive = activePreset === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => applyPreset(p)}
                      id={`preset-btn-${p.id}`}
                      className={`text-xs px-3.5 py-3 rounded-xl border transition-all duration-200 text-left flex flex-col justify-start gap-1 cursor-pointer w-[calc(50%-5px)] sm:w-auto flex-grow ${
                        isActive
                          ? "bg-[#fafaf8] border-natural-olive text-natural-olive font-semibold shadow-[0_4px_12px_rgba(90,90,64,0.06)]"
                          : "bg-white border-natural-border hover:border-natural-olive/60 hover:bg-natural-bg/20 text-natural-text-muted"
                      }`}
                    >
                      <div className="flex justify-between items-center w-full gap-2">
                        <span className="font-semibold truncate">{p.label}</span>
                        <span className={`text-[9px] font-mono shrink-0 px-1.5 py-0.5 rounded-md ${
                          isActive ? "bg-natural-olive text-white" : "bg-natural-bg text-natural-text-muted"
                        }`}>{p.tag}</span>
                      </div>
                      <span className="text-[10px] text-natural-text-muted opacity-85 truncate">
                        {p.programInterest} · {p.childAge} yrs
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Primary Configuration Inputs */}
            <form onSubmit={generateWithAI} className="bg-natural-card border border-natural-border rounded-[24px] p-6 shadow-[0_4px_20px_rgba(0,0,0,0.02)] space-y-5">
              <div className="border-b border-natural-border pb-3.5 mb-2">
                <h2 className="text-base font-serif font-bold text-natural-olive flex items-center gap-2">
                  <FileText className="w-4 h-4 text-natural-olive" />
                  Student & Parent Profile Setup
                </h2>
              </div>

              {/* Program Interest */}
              <div>
                <label htmlFor="program" className="block text-xs font-bold text-natural-olive uppercase tracking-wider mb-1.5">
                  Program of Interest <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="program"
                  required
                  placeholder="e.g. Robot Building, Scratch Coding"
                  value={programInterest}
                  onChange={(e) => {
                    setProgramInterest(e.target.value);
                    setActivePreset(null);
                  }}
                  className="w-full text-sm px-4 py-3 rounded-xl border border-natural-border focus:outline-none focus:border-natural-olive bg-[#fafaf8] focus:bg-white transition-all shadow-[inset_0_1px_2px_rgba(0,0,0,0.01)]"
                />
              </div>

              {/* Child Age */}
              <div>
                <label htmlFor="age" className="block text-xs font-bold text-natural-olive uppercase tracking-wider mb-1.5">
                  Child's Age <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min="3"
                  max="19"
                  id="age"
                  required
                  placeholder="e.g. 8"
                  value={childAge === "" ? "" : childAge}
                  onChange={(e) => {
                    const parsedVal = e.target.value === "" ? "" : Number(e.target.value);
                    setChildAge(parsedVal);
                    setActivePreset(null);
                  }}
                  className="w-full text-sm px-4 py-3 rounded-xl border border-natural-border focus:outline-none focus:border-natural-olive bg-[#fafaf8] focus:bg-white transition-all shadow-[inset_0_1px_2px_rgba(0,0,0,0.01)]"
                />
              </div>

              {/* Objection Query */}
              <div>
                <label htmlFor="query" className="block text-xs font-bold text-natural-olive uppercase tracking-wider mb-1.5">
                  Parent Objection / Main Concern <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="query"
                  required
                  rows={3}
                  placeholder="e.g. Your tuition fees are too high, or screening time is already too high."
                  value={parentQuery}
                  onChange={(e) => {
                    setParentQuery(e.target.value);
                    setActivePreset(null);
                  }}
                  className="w-full text-sm px-4 py-3 rounded-xl border border-natural-border focus:outline-none focus:border-natural-olive bg-[#fafaf8] focus:bg-white transition-all shadow-[inset_0_1px_2px_rgba(0,0,0,0.01)] resize-none leading-relaxed"
                />
                <p className="text-[11px] text-natural-text-muted mt-1.5 leading-normal italic">
                  Enter any objection. The AI compiler will structure an empathetic, pedagogical response instantly.
                </p>
              </div>

              {/* Buttons: AI generate and fast fallback */}
              <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  id="btn-generate-ai"
                  className="flex-1 bg-natural-olive hover:bg-natural-olive-light text-white font-semibold text-xs px-4 py-3.5 rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-40 flex items-center justify-center gap-1.5 focus:ring-2 focus:ring-natural-olive/20"
                >
                  <Sparkles className="w-4 h-4" />
                  Generate AI Script
                </button>
                <button
                  type="button"
                  onClick={generateWithTemplate}
                  disabled={loading}
                  id="btn-generate-template"
                  className="border border-natural-border text-natural-text-main hover:bg-[#fafaf8] bg-white font-semibold text-xs px-4 py-3.5 rounded-xl transition-all cursor-pointer disabled:opacity-40 flex items-center justify-center gap-1.5 shadow-[0_1px_2px_rgba(0,0,0,0.01)]"
                >
                  <Zap className="w-4 h-4 text-amber-600" />
                  Instant Template
                </button>
              </div>
            </form>

            {/* Notebook saved checklist */}
            {savedScripts.length > 0 && (
              <div className="bg-natural-card border border-natural-border rounded-[24px] p-6 shadow-[0_4px_20px_rgba(0,0,0,0.02)]">
                <h3 className="text-xs font-bold text-natural-olive uppercase tracking-wider mb-4 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-natural-olive" />
                  My Script Bank ({savedScripts.length})
                </h3>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {savedScripts.map((sav) => (
                    <div
                      key={sav.id}
                      onClick={() => handleLoadSaved(sav)}
                      className="group flex items-center justify-between p-3 rounded-xl border border-natural-border/60 bg-white hover:border-natural-olive hover:bg-[#fafaf8]/50 cursor-pointer transition-all duration-200 shadow-[0_1px_3px_rgba(0,0,0,0.01)]"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="text-xs font-bold text-natural-text-main truncate leading-tight font-serif text-sm">
                          {sav.title}
                        </p>
                        <p className="text-[10px] text-natural-text-muted flex items-center gap-1 mt-1 font-sans">
                          <Clock className="w-2.5 h-2.5" />
                          {sav.createdAt} · 
                          <span className={`inline-block border text-[8px] uppercase font-mono px-1 rounded-sm ${
                            sav.type === "ai" 
                              ? "border-natural-olive text-natural-olive bg-[#fafaf8]" 
                              : "border-amber-200 text-amber-800 bg-amber-50"
                          }`}>
                            {sav.type}
                          </span>
                        </p>
                      </div>
                      <button
                        onClick={(e) => handleDeleteSaved(sav.id, e)}
                        className="text-natural-text-muted hover:text-red-500 p-1.5 rounded-lg hover:bg-[#fafaf8] opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all shrink-0 cursor-pointer"
                        title="Delete script"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT PANEL: Generated Counselling Output */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Display error message */}
            {error && (
              <div className="bg-red-50 border border-red-200/60 text-red-900 rounded-[18px] p-5 text-xs leading-relaxed shadow-sm">
                <span className="font-bold flex items-center gap-1.5 text-red-950 mb-1 font-sans">
                  ⚠️ Workstation Notice
                </span>
                {error}
              </div>
            )}

            <div className="bg-natural-card border border-natural-border rounded-[24px] shadow-[0_4px_22px_rgba(0,0,0,0.02)] overflow-hidden flex flex-col min-h-[500px]">
              
              {/* Header inside result card */}
              <div className="border-b border-natural-border bg-[#fafaf8] p-5 shrink-0 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-white rounded-lg border border-natural-border">
                    <HeartHandshake className="w-4 h-4 text-natural-olive" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-natural-olive text-lg sm:text-xl italic">
                      {script ? `Strategy Workspace: ${programInterest || "Custom Academy"}` : "Admission Strategy Workspace"}
                    </h3>
                    <p className="text-[11px] text-natural-text-muted">
                      Refine calling blocks, model phonetic speaking pacing, or assemble copy decks.
                    </p>
                  </div>
                </div>

                {script && (
                  <div className="flex items-center gap-1.5 self-end sm:self-auto uppercase font-mono text-[9px] border border-natural-border bg-white px-2 py-1 rounded-lg text-natural-text-muted">
                    <span>Format:</span>
                    <span className={`font-bold ${generationType === "ai" ? "text-natural-olive" : "text-amber-700"}`}>
                      {generationType === "ai" ? "☘️ AI Generated" : "⚡ fallback dynamic"}
                    </span>
                  </div>
                )}
              </div>

              {/* Main space */}
              <div className="p-6 flex-1 flex flex-col">
                <AnimatePresence mode="wait">
                  {loading ? (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex-1 flex flex-col items-center justify-center py-24 text-center"
                    >
                      <div className="relative">
                        <div className="w-14 h-14 rounded-full border-4 border-natural-border border-t-natural-olive animate-spin mb-5" />
                        <Sparkles className="w-5 h-5 text-natural-olive absolute top-4.5 left-4.5 animate-pulse" />
                      </div>
                      <p className="font-serif font-bold text-natural-olive text-lg mb-1 italic">
                        Compiling Counselling Blueprint...
                      </p>
                      <p className="text-xs text-natural-text-muted max-w-xs leading-relaxed font-sans">
                        Aligning objection rebuttals, framing child diagnostics prompts, and customizing followups.
                      </p>
                    </motion.div>
                  ) : script ? (
                    <motion.div
                      key="results"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex-1 flex flex-col space-y-6"
                    >
                      {/* Tabs to switch overall calling approach */}
                      <div className="flex border-b border-natural-border pb-1 shrink-0">
                        <button
                          onClick={() => setActiveTab("phone")}
                          className={`flex items-center gap-2 text-xs py-2.5 px-4 font-bold rounded-t-xl transition-all border-b-2 cursor-pointer ${
                            activeTab === "phone"
                              ? "border-natural-olive bg-[#fafaf8] text-natural-olive"
                              : "border-transparent text-natural-text-muted hover:text-natural-text-main"
                          }`}
                        >
                          <Phone className="w-4 h-4" />
                          Phone Calling Flow
                        </button>
                        <button
                          onClick={() => setActiveTab("whatsapp")}
                          className={`flex items-center gap-2 text-xs py-2.5 px-4 font-bold rounded-t-xl transition-all border-b-2 cursor-pointer ${
                            activeTab === "whatsapp"
                              ? "border-natural-olive bg-[#fafaf8] text-natural-olive"
                              : "border-transparent text-natural-text-muted hover:text-natural-text-main"
                          }`}
                        >
                          <MessageSquare className="w-4 h-4" />
                          WhatsApp Follow-Up
                        </button>
                      </div>

                      {/* Displaying tab contents */}
                      {activeTab === "phone" ? (
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 flex-1">
                          
                          {/* Inside Left Panel: Navigation of the 6 calling steps */}
                          <div className="md:col-span-4 flex md:flex-col gap-1.5 overflow-x-auto md:overflow-x-visible pb-2.5 md:pb-0 shrink-0 select-none border-b md:border-b-0 md:border-r border-natural-border pr-0 md:pr-4">
                            {[
                              { id: "greeting", label: "Greeting", icon: Phone },
                              { id: "rapport", label: "Rapport Building", icon: HeartHandshake },
                              { id: "needs", label: "Need Analysis", icon: HelpCircle },
                              { id: "intro", label: "Program Intro", icon: FileText },
                              { id: "rebuttal", label: "Handle Objection", icon: Sparkles },
                              { id: "closing", label: "Call Closing", icon: ArrowRight },
                            ].map((s, index) => {
                              const isActive = activeSection === s.id;
                              return (
                                <button
                                  key={s.id}
                                  onClick={() => setActiveSection(s.id)}
                                  className={`flex items-center gap-2.5 text-left text-xs font-semibold px-3 py-3 rounded-xl transition-all w-full min-w-[130px] cursor-pointer block ${
                                    isActive
                                      ? "bg-[#fafaf8] border-l-4 border-l-natural-olive text-natural-olive shadow-[0_2px_8px_rgba(0,0,0,0.01)]"
                                      : "hover:bg-[#fafaf8]/50 text-natural-text-muted hover:text-natural-text-main border-l-4 border-l-transparent"
                                  }`}
                                >
                                  <s.icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-natural-olive" : "text-natural-text-muted"}`} />
                                  <span className="truncate">{index + 1}. {s.label}</span>
                                </button>
                              );
                            })}
                          </div>

                          {/* Inside Right Panel: Script section viewer and practice tool */}
                          <div className="md:col-span-8 flex flex-col justify-between space-y-4">
                            <div className="space-y-3.5">
                              {/* Header & Controls of current section */}
                              <div className="flex items-center justify-between border-b border-natural-border/60 pb-2">
                                <span className="font-serif text-xs font-semibold uppercase tracking-wider text-natural-olive border border-natural-olive px-2.5 py-0.5 rounded-md inline-block bg-white shadow-sm">
                                  {activeSection === "greeting" && "Caller Greeting"}
                                  {activeSection === "rapport" && "Rapport Phase"}
                                  {activeSection === "needs" && "Need Diagnostics"}
                                  {activeSection === "intro" && "Program Pitch"}
                                  {activeSection === "rebuttal" && "Objection Solved"}
                                  {activeSection === "closing" && "Commitment Close"}
                                </span>
                                
                                <div className="flex items-center gap-1.5">
                                  {/* Speech synthesizer command */}
                                  <button
                                    onClick={() => {
                                      const speakText = 
                                        activeSection === "greeting" ? script.greeting :
                                        activeSection === "rapport" ? script.rapportBuilding :
                                        activeSection === "needs" ? script.needAnalysis.join(". ") :
                                        activeSection === "intro" ? script.programIntroduction :
                                        activeSection === "rebuttal" ? script.objectionHandling :
                                        script.closing;
                                      handleSpeak(speakText, activeSection);
                                    }}
                                    className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                                      isSpeaking === activeSection
                                        ? "bg-red-50 border-red-200 text-red-700 hover:bg-red-100"
                                        : "bg-white border-natural-border text-natural-text-muted hover:text-natural-text-main hover:bg-[#fafaf8]"
                                    }`}
                                    title={isSpeaking === activeSection ? "Stop audio voice coach" : "Listen aloud to correct vocal pitch / inflection"}
                                    id={`speech-btn-${activeSection}`}
                                  >
                                    {isSpeaking === activeSection ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                                  </button>

                                  {/* Copy specific block to clipboard */}
                                  <button
                                    onClick={() => {
                                      const copyText = 
                                        activeSection === "greeting" ? script.greeting :
                                        activeSection === "rapport" ? script.rapportBuilding :
                                        activeSection === "needs" ? script.needAnalysis.join("\n") :
                                        activeSection === "intro" ? script.programIntroduction :
                                        activeSection === "rebuttal" ? script.objectionHandling :
                                        script.closing;
                                      copyToClipboard(copyText, activeSection);
                                    }}
                                    className="p-1.5 bg-white border border-natural-border text-natural-text-muted hover:text-natural-text-main rounded-lg hover:bg-[#fafaf8] transition-all cursor-pointer"
                                    title="Copy block text"
                                  >
                                    {copiedSection === activeSection ? (
                                      <Check className="w-4 h-4 text-emerald-700" />
                                    ) : (
                                      <Copy className="w-4 h-4" />
                                    )}
                                  </button>
                                </div>
                              </div>

                              {/* Editable script section body */}
                              <div className="bg-[#fafaf8] rounded-2xl p-5 border border-natural-border/30">
                                {activeSection === "needs" ? (
                                  <div className="space-y-3.5">
                                    <p className="text-[11px] text-natural-text-muted italic mb-1 uppercase tracking-wider font-semibold font-sans">
                                      Tip: Ask these questions naturally. Give plenty of space for user replies.
                                    </p>
                                    {script.needAnalysis.map((q, idx) => (
                                      <div key={idx} className="flex gap-3 items-start">
                                        <span className="w-6 h-6 rounded-full bg-white border border-natural-border text-natural-olive text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                                          {idx + 1}
                                        </span>
                                        <input
                                          type="text"
                                          value={q}
                                          onChange={(e) => handleNeedAnalysisChange(idx, e.target.value)}
                                          className="flex-1 text-sm bg-white border border-natural-border rounded-lg px-3 py-2 focus:outline-none focus:border-natural-olive font-serif text-natural-text-main"
                                        />
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <div>
                                    <p className="text-[11px] text-natural-text-muted italic mb-2 uppercase tracking-wider font-semibold font-sans">
                                      Coach Tip: You can adjust pronunciation styling below instantly before saving or copying:
                                    </p>
                                    <textarea
                                      rows={6}
                                      value={
                                        activeSection === "greeting" ? script.greeting :
                                        activeSection === "rapport" ? script.rapportBuilding :
                                        activeSection === "intro" ? script.programIntroduction :
                                        activeSection === "rebuttal" ? script.objectionHandling :
                                        script.closing
                                      }
                                      onChange={(e) => {
                                        const key = 
                                          activeSection === "greeting" ? "greeting" :
                                          activeSection === "rapport" ? "rapportBuilding" :
                                          activeSection === "intro" ? "programIntroduction" :
                                          activeSection === "rebuttal" ? "objectionHandling" :
                                          "closing";
                                        handleSectionTextChange(key, e.target.value);
                                      }}
                                      className="w-full text-base sm:text-[17px] bg-white border border-natural-border rounded-xl px-4 py-3 focus:outline-none focus:border-natural-olive font-serif text-natural-text-main leading-relaxed resize-none shadow-[inset_0_1px_2px_rgba(0,0,0,0.015)]"
                                    />
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="bg-natural-green-bg/80 border border-natural-green-border/50 rounded-xl p-4 text-xs text-natural-green-text flex items-start gap-2.5 leading-relaxed font-sans">
                              <span className="text-sm">🍃</span>
                              <p>
                                <strong>Admission Guide Advice:</strong> Empathy overcomes pricing or distance fear. Frame this as a holistic cognitive roadmap for {childAge || "[Age]"} years old instead of simple hobby tutoring.
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        /* WhatsApp Tab Screen View */
                        <div className="flex-1 flex flex-col justify-between space-y-4 font-sans">
                          <div className="space-y-3.5">
                            <div className="flex justify-between items-center border-b border-natural-border/60 pb-2">
                              <span className="text-xs font-semibold text-natural-olive uppercase tracking-wider font-sans">
                                WhatsApp Copy Deck Preview
                              </span>

                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handleSpeak(script.whatsappMessage, "whatsappMessage")}
                                  className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                                    isSpeaking === "whatsappMessage"
                                      ? "bg-red-50 border-red-200 text-red-650"
                                      : "bg-white border-natural-border text-natural-text-muted hover:text-natural-text-main"
                                  }`}
                                  title="Listen back to WhatsApp follow up voice profile"
                                >
                                  {isSpeaking === "whatsappMessage" ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                                </button>

                                <button
                                  onClick={() => copyToClipboard(script.whatsappMessage, "whatsappMessage")}
                                  className="text-xs text-natural-olive hover:text-white border border-natural-olive hover:bg-natural-olive bg-white transition-all font-semibold py-1.5 px-3 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-[0_1px_2px_rgba(0,0,0,0.02)]"
                                  id="btn-copy-wa"
                                >
                                  {copiedSection === "whatsappMessage" ? (
                                    <>
                                      <Check className="w-3 mx-0.5 text-emerald-100" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3 mx-0.5" />
                                      Copy Slide
                                    </>
                                  )}
                                </button>
                              </div>
                            </div>

                            <p className="text-[11px] text-natural-text-muted italic font-sans uppercase tracking-wider font-semibold">
                              Tip: You can change or format custom headers below before deploying:
                            </p>

                            <textarea
                              rows={11}
                              value={script.whatsappMessage}
                              onChange={(e) => handleSectionTextChange("whatsappMessage", e.target.value)}
                              className="w-full text-sm font-sans bg-natural-green-bg text-natural-green-text rounded-2xl border border-dashed border-[#c0d0c0] p-5 leading-relaxed focus:outline-none focus:border-natural-olive resize-none shadow-[inset_0_1.5px_3px_rgba(0,0,0,0.015)]"
                            />
                          </div>

                          <span className="text-[10px] text-natural-text-muted font-medium italic block">
                            Note: Emojis and structured spacings are optimized automatically for direct client messaging.
                          </span>
                        </div>
                      )}

                      {/* Footer Actions: Master Controls */}
                      <div className="border-t border-natural-border pt-5 mt-4 flex flex-col sm:flex-row gap-2.5 shrink-0">
                        <button
                          onClick={handleSaveScript}
                          className="flex-1 border border-natural-border hover:border-natural-text-muted text-natural-text-main bg-white hover:bg-[#fafaf8] font-bold text-xs px-4 py-3.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-[0_1px_3px_rgba(0,0,0,0.012)]"
                          id="btn-save-notebook"
                        >
                          <Bookmark className="w-4 h-4 text-natural-olive" />
                          Save Script to Notebook
                        </button>
                        
                        <button
                          onClick={copyAllScript}
                          className="flex-1 bg-natural-olive hover:bg-natural-olive-light text-white font-bold text-xs px-4 py-3.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(90,90,64,0.15)]"
                          id="btn-copy-all"
                        >
                          {copiedAll ? (
                            <>
                              <Check className="w-4 h-4 text-emerald-100" />
                              Copied All Scripts!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              Copy Complete Call Script File
                            </>
                          )}
                        </button>
                      </div>

                    </motion.div>
                  ) : (
                    /* Initial Empty Screen State */
                    <motion.div
                      key="empty-state"
                      className="flex-1 flex flex-col items-center justify-center text-center py-20 px-4"
                    >
                      <div className="w-16 h-16 rounded-3xl bg-white border border-natural-border flex items-center justify-center mb-6 text-natural-olive shadow-[0_4px_16px_rgba(90,90,64,0.03)]">
                        <Phone className="w-7 h-7" id="empty-state-phone" />
                      </div>
                      <h4 className="font-serif font-bold text-natural-olive text-lg mb-1.5 italic">
                        No Call Strategy Selected
                      </h4>
                      <p className="text-xs text-natural-text-muted max-w-sm leading-relaxed font-sans font-medium">
                        Select a quick launcher scenario from the left panel, or write customized student parameters, then click <strong>Generate AI Script</strong> to synthesize your strategy.
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4.5 mt-8 text-left max-w-md w-full">
                        <div className="border border-natural-border p-3.5 rounded-xl text-xs text-natural-text-muted bg-white/60 shadow-[0_2px_8px_rgba(0,0,0,0.01)]">
                          <strong className="text-natural-text-main block mb-1 font-medium font-serif italic text-sm">💬 Diagnostic Prompts</strong>
                          Builds 3-4 specialized, open-ended client diagnostic questions based on course type and child traits.
                        </div>
                        <div className="border border-natural-border p-3.5 rounded-xl text-xs text-natural-text-muted bg-white/60 shadow-[0_2px_8px_rgba(0,0,0,0.01)]">
                          <strong className="text-natural-text-main block mb-1 font-medium font-serif italic text-sm">🛠️ Pedagogical Alignment</strong>
                          Overcomes deep parent doubts or pricing constraints through tailored educational value arguments.
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

            </div>

          </div>

        </div>
      </main>
    </div>
  );
}
