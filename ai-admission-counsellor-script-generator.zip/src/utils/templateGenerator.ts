import { GeneratedScript } from "../types";

export function generateLocalFallback(query: string, age: number, program: string): GeneratedScript {
  const cleanQuery = query.trim() || "No custom query specified";
  const cleanProgram = program.trim() || "Academic & Skills Program";
  const cleanAge = age || "[Age]";

  return {
    greeting: `Hello Ma'am/Sir! Thank you so much for registering your interest in our ${cleanProgram} program. My name is [Counsellor Name] calling from the admissions team. I hope I'm catching you at a good time today?`,
    
    rapportBuilding: `That's wonderful to hear. I noted that your child is ${cleanAge} years old. This is an absolutely fantastic age for learning and habit-forming! At this age, children's cognitive abilities are expanding rapidly, and they love engaging with interactive formats. Have they shown interest in ${cleanProgram} before, or would this be their first time trying something like this?`,
    
    needAnalysis: [
      `What are your primary goals or expectations from this ${cleanProgram} program?`,
      `Does your child have any prior experience with similar classes, or are they beginning as a complete beginner?`,
      `What specific skills—such as critical thinking, creative expression, or focus—are you most eager for your child to develop?`
    ],
    
    programIntroduction: `Our ${cleanProgram} program is specially structured for ${cleanAge}-year-olds. It focuses on hand-on practical projects, confidence building, and nurturing future-ready skills. Instead of passive lessons, we place kids in the driver's seat where they learn by active doing, ensuring high retention and genuine excitement.`,
    
    objectionHandling: `Regarding your query/concern: "${cleanQuery}"

I completely understand where you are coming from, and it is a very valid perspective that many of our current parents also raised initially. 

What we've seen is that once children start the sessions, the return on engagement is massive. Our curriculum is tailored for high interaction, regular expert human feedback, and small class sizes. This is why our parents see a dramatic increase in self-reliance, creative problem-solving, and core skills that transfer directly into their regular academic habits. It's a true investment in their developmental journey rather than just basic tutoring.`,
    
    closing: `To see if this is indeed the right fit, I'd highly recommend scheduling a complimentary 30-minute 1-on-1 trial workspace session. They'll complete their first project, and you can see our methodology firsthand. 

Would this coming Saturday or Sunday work better for a quick 30-minute session?`,
    
    whatsappMessage: `*AI Admission Portal: ${cleanProgram} Details* 📥

Hello,

Thank you for your valuable time on our call today! 

As discussed, I am sharing the program details for your reference:
🎓 *Program:* ${cleanProgram}
👶 *Ages:* Specially aligned for children of ${cleanAge} years
🎯 *Syllabus Focus:* Practical projects, analytical thinking, and future-ready confidence.
💡 *Your Concern Addressed:* Customized guidance, high-attention feedback, and personalized milestones.

*Special Enrollment Opportunity:*
We have unlocked a *Complimentary 1-on-1 Assessment Session* for this week. 

Please reply to this message to secure a preferred slot or if you have any questions!

Warm regards,
[Admissions Counsellor]
Admissions Office`
  };
}
